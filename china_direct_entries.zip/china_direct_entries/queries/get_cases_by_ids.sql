-- Same as get_cases.sql but restricted to IDs loaded into #TempIds
-- (used when config.ID_LIST / --ids-file is supplied).
SELECT
    c.id              AS id,
    c.name            AS name,
    c.[native name]   AS native_name,
    c.address         AS address,
    c.pccity          AS pccity,
    c.postcode        AS postcode
FROM companies c
INNER JOIN #TempIds t ON t.id = c.id
