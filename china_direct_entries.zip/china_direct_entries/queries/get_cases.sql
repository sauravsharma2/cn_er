-- Entries for China name/address enrichment.
-- Output column aliases are fixed: the pipeline depends on them.
SELECT
    c.id              AS id,
    c.name            AS name,
    c.[native name]   AS native_name,
    c.address         AS address,
    c.pccity          AS pccity,
    c.postcode        AS postcode
FROM companies c
